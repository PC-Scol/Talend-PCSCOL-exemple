#!/bin/bash
start=1625097600		# 01/07/2021
end=`date +%s`			# fin est positionnée à la date du jour
pas=604800				#une semaine
token=					#token à obtenir et renseigner
purge=O					#Si O, purge lors de la premiere itération; Si N, aucune purge
url_ins=https://ins.ETABLISSEMENT.pc-scol.fr/
it=1
echo "Extraction de $start à $end par $pas"
while [ $start -lt $end ]
do
  borne_mini=$start
  borne_maxi=$(($start + $pas))
  if [ $it -gt 1 ] && [ ${purge}=="O" ]
  then
	#purge uniquement lors du premier passage si demandée
	# => désactivée lors des passages >1
    purge=N
  fi

  echo "$it. de ${borne_mini} à ${borne_maxi};purge:${purge}"
  #TODO : METTRE LE CHEMIN UNIX ABSOLU DE demo_extraction_flux_inscription_run.sh POUR POUVOIR L'APPELER
  ./demo_extraction_flux_inscription_run.sh --context_param url_ins=${url_ins} --context_param token=${token} --context_param timestamp_debut=${borne_mini} --context_param timestamp_fin=${borne_maxi} --context_param purge_table_extraction=${purge}
  start=$borne_maxi
  it=$(($it +1))
  # exit
done